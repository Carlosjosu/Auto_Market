package com.unl.sistema;

import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration(proxyBeanMethods = false)
public class TestcontainersConfiguration {

    // TODO Configure your Testcontainers here.
    //  See https://docs.spring.io/spring-boot/reference/testing/testcontainers.html for details.
}
