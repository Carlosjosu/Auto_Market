package com.unl.sistema.base.models;

public enum CategoriaEnum {
    CAMIONETA, CONVERTIBLE, MINIVAN, FURGONETA, DEPORTIVO, VEHICULO_COMERCIAL, TODO_TERRENO, CLASICO;
}
