package com.unl.sistema.base.models;

public enum TipoCombustibleEnum {
    DIESEL, ECOPAIS, SUPER, EXTRA, ELECTRICO;
}